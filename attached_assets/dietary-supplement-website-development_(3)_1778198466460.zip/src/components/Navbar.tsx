import { useState } from "react";
import Logo from "./Logo";
import { useAuth, useCart, useRouter } from "../store";
import type { Route } from "../types";

const links: { label: string; route: Route }[] = [
  { label: "Accueil", route: { name: "home" } },
  { label: "Produits", route: { name: "products" } },
  { label: "La Science", route: { name: "science" } },
  { label: "À propos", route: { name: "about" } },
  { label: "Contact", route: { name: "contact" } },
];

export default function Navbar() {
  const { route, navigate } = useRouter();
  const { user, logout } = useAuth();
  const { count } = useCart();
  const [menuOpen, setMenuOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  const isActive = (r: Route) => r.name === route.name;

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-energum-blue-deep/85 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
        <button onClick={() => navigate({ name: "home" })} className="shrink-0">
          <Logo size={42} variant="light" />
        </button>

        <nav className="hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <button
              key={l.label}
              onClick={() => navigate(l.route)}
              className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
                isActive(l.route)
                  ? "bg-white/15 text-white"
                  : "text-blue-100/80 hover:bg-white/10 hover:text-white"
              }`}
            >
              {l.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate({ name: "cart" })}
            className="relative rounded-full bg-white/10 p-2.5 text-white transition hover:bg-white/20"
            aria-label="Panier"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z" />
              <line x1="3" y1="6" x2="21" y2="6" />
              <path d="M16 10a4 4 0 0 1-8 0" />
            </svg>
            {count > 0 && (
              <span className="absolute -right-1 -top-1 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-energum-orange px-1 text-[10px] font-bold text-white">
                {count}
              </span>
            )}
          </button>

          {user ? (
            <div className="relative">
              <button
                onClick={() => setProfileOpen((v) => !v)}
                className="flex items-center gap-2 rounded-full bg-white/10 py-1.5 pl-1.5 pr-3 text-white transition hover:bg-white/20"
              >
                <span className="grid h-7 w-7 place-items-center rounded-full bg-gradient-to-br from-energum-orange to-energum-amber text-xs font-bold text-white">
                  {user.fullName.charAt(0).toUpperCase()}
                </span>
                <span className="hidden text-sm font-semibold sm:inline">{user.fullName.split(" ")[0]}</span>
              </button>
              {profileOpen && (
                <div
                  onMouseLeave={() => setProfileOpen(false)}
                  className="absolute right-0 mt-2 w-56 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl"
                >
                  <div className="border-b border-slate-100 px-4 py-3">
                    <div className="text-xs text-slate-500">Connecté en tant que</div>
                    <div className="truncate text-sm font-semibold text-slate-900">{user.email}</div>
                  </div>
                  <button
                    onClick={() => {
                      setProfileOpen(false);
                      navigate({ name: "account" });
                    }}
                    className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-slate-700 hover:bg-slate-50"
                  >
                    <span>👤</span> Mon compte
                  </button>
                  <button
                    onClick={() => {
                      setProfileOpen(false);
                      navigate({ name: "cart" });
                    }}
                    className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-slate-700 hover:bg-slate-50"
                  >
                    <span>🛒</span> Mon panier
                  </button>
                  <button
                    onClick={() => {
                      logout();
                      setProfileOpen(false);
                      navigate({ name: "home" });
                    }}
                    className="flex w-full items-center gap-2 border-t border-slate-100 px-4 py-2.5 text-left text-sm font-semibold text-rose-600 hover:bg-rose-50"
                  >
                    <span>🚪</span> Se déconnecter
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="hidden items-center gap-2 sm:flex">
              <button
                onClick={() => navigate({ name: "login" })}
                className="rounded-full px-4 py-2 text-sm font-semibold text-white hover:bg-white/10"
              >
                Connexion
              </button>
              <button
                onClick={() => navigate({ name: "register" })}
                className="rounded-full bg-gradient-to-r from-energum-orange to-energum-amber px-4 py-2 text-sm font-bold text-white shadow-lg shadow-orange-500/30 transition hover:brightness-110"
              >
                S'inscrire
              </button>
            </div>
          )}

          <button
            className="rounded-full bg-white/10 p-2.5 text-white lg:hidden"
            onClick={() => setMenuOpen((v) => !v)}
            aria-label="Menu"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <line x1="3" y1="6" x2="21" y2="6" />
              <line x1="3" y1="12" x2="21" y2="12" />
              <line x1="3" y1="18" x2="21" y2="18" />
            </svg>
          </button>
        </div>
      </div>

      {menuOpen && (
        <div className="border-t border-white/10 bg-energum-blue-deep px-4 py-3 lg:hidden">
          <div className="flex flex-col gap-1">
            {links.map((l) => (
              <button
                key={l.label}
                onClick={() => {
                  navigate(l.route);
                  setMenuOpen(false);
                }}
                className="rounded-lg px-4 py-2.5 text-left text-sm font-semibold text-blue-100 hover:bg-white/10"
              >
                {l.label}
              </button>
            ))}
            {!user && (
              <div className="mt-2 flex gap-2 border-t border-white/10 pt-3">
                <button
                  onClick={() => {
                    navigate({ name: "login" });
                    setMenuOpen(false);
                  }}
                  className="flex-1 rounded-full border border-white/30 px-4 py-2 text-sm font-semibold text-white"
                >
                  Connexion
                </button>
                <button
                  onClick={() => {
                    navigate({ name: "register" });
                    setMenuOpen(false);
                  }}
                  className="flex-1 rounded-full bg-energum-orange px-4 py-2 text-sm font-bold text-white"
                >
                  S'inscrire
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
