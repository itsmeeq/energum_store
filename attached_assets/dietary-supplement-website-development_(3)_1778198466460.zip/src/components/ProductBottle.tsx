type Props = {
  variant: "orange" | "blue";
  label: string;
  size?: number;
  className?: string;
};

export default function ProductBottle({ variant, label, size = 200, className = "" }: Props) {
  const isOrange = variant === "orange";
  const isFocus = label === "FOCUS";
  const cap = isOrange ? "#e35d0d" : "#1d3f8a";
  const capDark = isOrange ? "#a93f06" : "#0e2658";
  const body = isOrange ? "#f57617" : "#0a2e6d";
  const bodyDark = isOrange ? "#c95a0e" : "#061d47";
  const shine = isOrange ? "#ffb774" : "#5b8ad8";
  const labelBg = isOrange ? "#d95a0e" : "#07255a";
  const accentText = isOrange ? "#ffe6cc" : "#cfe0ff";

  return (
    <svg
      viewBox="0 0 200 340"
      width={size}
      height={(size * 340) / 200}
      className={className}
      aria-label={`Flacon ${label}`}
    >
      <defs>
        <linearGradient id={`body-${variant}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={shine} />
          <stop offset="40%" stopColor={body} />
          <stop offset="100%" stopColor={bodyDark} />
        </linearGradient>
        <linearGradient id={`cap-${variant}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={cap} />
          <stop offset="100%" stopColor={capDark} />
        </linearGradient>
        <radialGradient id={`gloss-${variant}`} cx="30%" cy="30%" r="50%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
        </radialGradient>
        <clipPath id={`labelClip-${variant}`}>
          <rect x="40" y="54" width="120" height="210" rx="14" />
        </clipPath>
      </defs>

      {/* shadow */}
      <ellipse cx="100" cy="330" rx="70" ry="6" fill="#000" opacity="0.25" />

      {/* cap */}
      <rect x="55" y="14" width="90" height="42" rx="8" fill={`url(#cap-${variant})`} />
      <rect x="55" y="48" width="90" height="6" rx="2" fill={capDark} opacity="0.5" />

      {/* body */}
      <rect x="40" y="54" width="120" height="270" rx="14" fill={`url(#body-${variant})`} />

      {/* label background */}
      <rect x="44" y="88" width="112" height="200" rx="8" fill={labelBg} opacity="0.45" />

      {/* ENERGUM big */}
      <text
        x="100"
        y="118"
        textAnchor="middle"
        fontFamily="Plus Jakarta Sans, Inter, sans-serif"
        fontWeight="900"
        fontSize="18"
        fill="#fff"
        letterSpacing="2"
      >
        ENERGUM
      </text>

      {/* FOCUS / SOMMEIL */}
      <text
        x="100"
        y="142"
        textAnchor="middle"
        fontFamily="Plus Jakarta Sans, Inter, sans-serif"
        fontWeight="800"
        fontSize="16"
        fill={accentText}
        letterSpacing="4"
      >
        {label}
      </text>

      {/* blue bar */}
      <rect x="50" y="150" width="100" height="14" rx="3" fill={isOrange ? "#0a2e6d" : "#f57617"} opacity="0.9" />
      <text
        x="100"
        y="160"
        textAnchor="middle"
        fontFamily="Plus Jakarta Sans, Inter, sans-serif"
        fontWeight="700"
        fontSize="7"
        fill="#fff"
        letterSpacing="0.5"
      >
        GUMMIES CONCENTRATION NATURELS
      </text>

      {/* 3 icons row */}
      {isFocus ? (
        <>
          {/* Target */}
          <g transform="translate(52, 178)">
            <circle cx="10" cy="10" r="8" fill="none" stroke="#fff" strokeWidth="1.2" />
            <circle cx="10" cy="10" r="3" fill="none" stroke="#fff" strokeWidth="1.2" />
            <line x1="10" y1="0" x2="10" y2="4" stroke="#fff" strokeWidth="1.2" />
            <line x1="10" y1="16" x2="10" y2="20" stroke="#fff" strokeWidth="1.2" />
            <line x1="0" y1="10" x2="4" y2="10" stroke="#fff" strokeWidth="1.2" />
            <line x1="16" y1="10" x2="20" y2="10" stroke="#fff" strokeWidth="1.2" />
            <text x="10" y="32" textAnchor="middle" fontSize="5" fill="#fff" fontWeight="600">CONCENTRATION</text>
            <text x="10" y="38" textAnchor="middle" fontSize="5" fill="#fff" fontWeight="600">AMÉLIORÉE</text>
          </g>
          {/* Lightbulb */}
          <g transform="translate(90, 178)">
            <path d="M10 2a6 6 0 0 0-6 6c0 2 1 3.5 2 4.5v2a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-2c1-1 2-2.5 2-4.5a6 6 0 0 0-6-6z" fill="none" stroke="#fff" strokeWidth="1.2" />
            <line x1="8" y1="16" x2="12" y2="16" stroke="#fff" strokeWidth="1" />
            <line x1="9" y1="19" x2="11" y2="19" stroke="#fff" strokeWidth="1" />
            <text x="10" y="32" textAnchor="middle" fontSize="5" fill="#fff" fontWeight="600">CLARTÉ</text>
            <text x="10" y="38" textAnchor="middle" fontSize="5" fill="#fff" fontWeight="600">MENTALE</text>
          </g>
          {/* Brain */}
          <g transform="translate(128, 178)">
            <path d="M6 6c0-3 2-5 5-5s5 2 5 5c0 3-2 6-5 8-3-2-5-5-5-8z" fill="none" stroke="#fff" strokeWidth="1.2" />
            <circle cx="8" cy="5" r="1" fill="#fff" />
            <circle cx="12" cy="5" r="1" fill="#fff" />
            <path d="M8 9c1 1 3 1 4 0" fill="none" stroke="#fff" strokeWidth="0.8" />
            <text x="10" y="32" textAnchor="middle" fontSize="5" fill="#fff" fontWeight="600">MÉMOIRE &amp;</text>
            <text x="10" y="38" textAnchor="middle" fontSize="5" fill="#fff" fontWeight="600">APPRENTISSAGE</text>
          </g>
        </>
      ) : (
        <>
          {/* Moon */}
          <g transform="translate(52, 178)">
            <path d="M14 3a7 7 0 1 1-9 9 5 5 0 0 0 9-9z" fill="none" stroke="#fff" strokeWidth="1.2" />
            <text x="10" y="32" textAnchor="middle" fontSize="5" fill="#fff" fontWeight="600">FAVORISE</text>
            <text x="10" y="38" textAnchor="middle" fontSize="5" fill="#fff" fontWeight="600">L'ENDORMISSEMENT</text>
          </g>
          {/* Brain sleep */}
          <g transform="translate(90, 178)">
            <path d="M6 6c0-3 2-5 5-5s5 2 5 5c0 3-2 6-5 8-3-2-5-5-5-8z" fill="none" stroke="#fff" strokeWidth="1.2" />
            <circle cx="8" cy="5" r="1" fill="#fff" />
            <circle cx="12" cy="5" r="1" fill="#fff" />
            <text x="10" y="32" textAnchor="middle" fontSize="5" fill="#fff" fontWeight="600">AMÉLIORE</text>
            <text x="10" y="38" textAnchor="middle" fontSize="5" fill="#fff" fontWeight="600">LA QUALITÉ DU</text>
            <text x="10" y="44" textAnchor="middle" fontSize="5" fill="#fff" fontWeight="600">SOMMEIL</text>
          </g>
          {/* Clock */}
          <g transform="translate(128, 178)">
            <circle cx="10" cy="10" r="8" fill="none" stroke="#fff" strokeWidth="1.2" />
            <line x1="10" y1="10" x2="10" y2="5" stroke="#fff" strokeWidth="1.2" />
            <line x1="10" y1="10" x2="14" y2="10" stroke="#fff" strokeWidth="1" />
            <text x="10" y="32" textAnchor="middle" fontSize="5" fill="#fff" fontWeight="600">RÉDUIT</text>
            <text x="10" y="38" textAnchor="middle" fontSize="5" fill="#fff" fontWeight="600">LA FATIGUE</text>
            <text x="10" y="44" textAnchor="middle" fontSize="5" fill="#fff" fontWeight="600">MENTALE</text>
          </g>
        </>
      )}

      {/* 100% naturel */}
      <text x="100" y="240" textAnchor="middle" fontSize="8" fill="#fff" fontWeight="800" letterSpacing="1">
        100% NATUREL
      </text>
      <text x="100" y="252" textAnchor="middle" fontSize="7" fill="#fff" fontWeight="600" opacity="0.9">
        SANS DÉPENDANCE
      </text>

      {/* 60 GUMMIES */}
      <text x="100" y="272" textAnchor="middle" fontSize="10" fill="#fff" fontWeight="900" letterSpacing="1">
        60 GUMMIES
      </text>
      <text x="100" y="284" textAnchor="middle" fontSize="6" fill="#fff" fontWeight="600" opacity="0.85" letterSpacing="0.5">
        COMPLÉMENT ALIMENTAIRE
      </text>

      {/* Side badges */}
      <g transform="translate(168, 110)">
        <rect x="0" y="0" width="24" height="130" rx="4" fill={labelBg} opacity="0.5" />
        {/* leaf */}
        <g transform="translate(12, 14)">
          <ellipse cx="0" cy="0" rx="5" ry="8" fill="none" stroke="#fff" strokeWidth="1" />
          <line x1="0" y1="-8" x2="0" y2="8" stroke="#fff" strokeWidth="0.8" />
        </g>
        <text x="12" y="30" textAnchor="middle" fontSize="4.5" fill="#fff" fontWeight="700">100%</text>
        <text x="12" y="36" textAnchor="middle" fontSize="4.5" fill="#fff" fontWeight="700">NATUREL</text>

        {/* wheat */}
        <g transform="translate(12, 50)">
          <path d="M0-6l-3 4h6z" fill="none" stroke="#fff" strokeWidth="1" />
          <line x1="0" y1="-6" x2="0" y2="6" stroke="#fff" strokeWidth="1" />
        </g>
        <text x="12" y="66" textAnchor="middle" fontSize="4.5" fill="#fff" fontWeight="700">SANS</text>
        <text x="12" y="72" textAnchor="middle" fontSize="4.5" fill="#fff" fontWeight="700">GLUTEN</text>

        {/* vegan */}
        <g transform="translate(12, 86)">
          <circle cx="0" cy="0" r="5" fill="none" stroke="#fff" strokeWidth="1" />
          <path d="M-2 2l2-6 2 6z" fill="none" stroke="#fff" strokeWidth="0.8" />
        </g>
        <text x="12" y="102" textAnchor="middle" fontSize="4.5" fill="#fff" fontWeight="700">VÉGAN</text>

        {/* lab */}
        <g transform="translate(12, 116)">
          <path d="M-3-4h6l-2 8h-2z" fill="none" stroke="#fff" strokeWidth="1" />
          <line x1="-4" y1="-4" x2="4" y2="-4" stroke="#fff" strokeWidth="1" />
        </g>
        <text x="12" y="130" textAnchor="middle" fontSize="4.5" fill="#fff" fontWeight="700">SANS</text>
        <text x="12" y="136" textAnchor="middle" fontSize="4.5" fill="#fff" fontWeight="700">OGM</text>
      </g>

      {/* gloss */}
      <rect x="40" y="54" width="120" height="270" rx="14" fill={`url(#gloss-${variant})`} />
      {/* highlight */}
      <rect x="48" y="60" width="10" height="255" rx="5" fill="#fff" opacity="0.18" />
    </svg>
  );
}
