type Props = {
  variant?: "light" | "dark";
  size?: number;
  withText?: boolean;
  className?: string;
};

export default function Logo({ variant = "light", size = 40, withText = true, className = "" }: Props) {
  const textColor = variant === "light" ? "text-white" : "text-energum-blue";
  const accent = variant === "light" ? "text-energum-amber" : "text-energum-orange";

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 64 64"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0"
        aria-label="ENERGUM logo"
      >
        <defs>
          <radialGradient id="logoBg" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#1a4fa8" />
            <stop offset="100%" stopColor="#061d47" />
          </radialGradient>
          <linearGradient id="boltGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#ffd166" />
            <stop offset="100%" stopColor="#f57617" />
          </linearGradient>
        </defs>
        {/* circle background */}
        <circle cx="32" cy="32" r="30" fill="url(#logoBg)" stroke="#2c5fb8" strokeWidth="1.5" />
        {/* neural dots */}
        <g fill="#7fb3ff" opacity="0.55">
          <circle cx="14" cy="22" r="1.2" />
          <circle cx="10" cy="34" r="1" />
          <circle cx="16" cy="44" r="1.2" />
          <circle cx="22" cy="14" r="1" />
          <circle cx="50" cy="24" r="1.2" />
          <circle cx="54" cy="40" r="1" />
          <circle cx="46" cy="50" r="1.2" />
        </g>
        {/* head profile */}
        <path
          d="M44 20c0-3-3-6-7-7-6-1.5-13 1-17 6-3 4-4 9-3 14 1 4 4 7 4 11 0 2-1 3-1 5h11v-4l4-2c2-1 3-3 3-5 0-1-1-2-1-3 2 0 4-1 5-3 1-2 2-4 2-7 0-2 0-4 0-5z"
          fill="#1f4f9e"
          stroke="#7fb3ff"
          strokeWidth="0.8"
          opacity="0.85"
        />
        {/* lightning bolt */}
        <path
          d="M34 14L22 34h8l-4 16 14-22h-8l4-14z"
          fill="url(#boltGrad)"
          stroke="#ffb547"
          strokeWidth="0.6"
          strokeLinejoin="round"
        />
      </svg>
      {withText && (
        <div className="leading-none">
          <div className={`font-extrabold tracking-tight ${textColor}`} style={{ fontSize: size * 0.55 }}>
            ENER<span className={accent}>GUM</span>
          </div>
          <div
            className={`mt-1 font-semibold tracking-[0.2em] ${variant === "light" ? "text-blue-200/80" : "text-energum-blue/60"}`}
            style={{ fontSize: size * 0.18 }}
          >
            FOCUS &amp; SOMMEIL
          </div>
        </div>
      )}
    </div>
  );
}
