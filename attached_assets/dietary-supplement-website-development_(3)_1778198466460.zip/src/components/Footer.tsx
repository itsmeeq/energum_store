import Logo from "./Logo";
import { useRouter } from "../store";

export default function Footer() {
  const { navigate } = useRouter();
  return (
    <footer className="bg-energum-blue-deep text-blue-100">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <Logo size={44} />
            <p className="mt-4 text-sm leading-relaxed text-blue-200/80">
              Compléments alimentaires naturels formulés par des chercheurs. 100% Naturel — Vegan — Sans gluten — Sans OGM.
            </p>
            <div className="mt-5 flex gap-2">
              {["🌿", "🌾", "🍃", "🧪"].map((e, i) => (
                <span key={i} className="grid h-9 w-9 place-items-center rounded-full bg-white/10 text-base">
                  {e}
                </span>
              ))}
            </div>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-bold uppercase tracking-wider text-white">Produits</h4>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => navigate({ name: "product", slug: "focus" })} className="hover:text-white">ENERGUM Focus</button></li>
              <li><button onClick={() => navigate({ name: "product", slug: "sommeil" })} className="hover:text-white">ENERGUM Sommeil</button></li>
              <li><button onClick={() => navigate({ name: "products" })} className="hover:text-white">Pack Duo</button></li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-bold uppercase tracking-wider text-white">Société</h4>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => navigate({ name: "about" })} className="hover:text-white">À propos</button></li>
              <li><button onClick={() => navigate({ name: "science" })} className="hover:text-white">La Science</button></li>
              <li><button onClick={() => navigate({ name: "contact" })} className="hover:text-white">Contact</button></li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-bold uppercase tracking-wider text-white">Newsletter</h4>
            <p className="mb-3 text-sm text-blue-200/80">Conseils santé, études et offres exclusives.</p>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                alert("Merci pour votre inscription !");
              }}
              className="flex overflow-hidden rounded-full bg-white/10 ring-1 ring-white/20 focus-within:ring-energum-amber"
            >
              <input
                type="email"
                required
                placeholder="Votre email"
                className="flex-1 bg-transparent px-4 py-2.5 text-sm text-white placeholder:text-blue-200/60 outline-none"
              />
              <button className="bg-energum-orange px-4 text-sm font-bold text-white hover:brightness-110">OK</button>
            </form>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 text-xs text-blue-200/70 md:flex-row">
          <div>© {new Date().getFullYear()} ENERGUM. Tous droits réservés. Compléments alimentaires — ne se substituent pas à une alimentation variée.</div>
          <div className="flex gap-4">
            <a className="hover:text-white" href="#">Mentions légales</a>
            <a className="hover:text-white" href="#">CGV</a>
            <a className="hover:text-white" href="#">Confidentialité</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
