import { useState } from "react";
import ProductBottle from "../components/ProductBottle";
import { products, reviews } from "../data/products";
import { useCart, useRouter } from "../store";

type Props = { slug: "focus" | "sommeil" };

export default function ProductDetail({ slug }: Props) {
  const product = products.find((p) => p.slug === slug)!;
  const productReviews = reviews.filter((r) => r.productId === product.id);
  const { add } = useCart();
  const { navigate } = useRouter();
  const [qty, setQty] = useState(1);
  const [tab, setTab] = useState<"description" | "ingredients" | "usage" | "avis">("description");
  const [expandedBenefit, setExpandedBenefit] = useState<string | null>(null);
  const [expandedIngredient, setExpandedIngredient] = useState<string | null>(null);
  const [showRituel, setShowRituel] = useState(false);

  const isOrange = product.color === "orange";

  return (
    <div className="bg-slate-50">
      {/* Breadcrumb */}
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-3 text-sm text-slate-500 sm:px-6 lg:px-8">
          <button onClick={() => navigate({ name: "home" })} className="hover:text-energum-blue">Accueil</button>
          <span className="mx-2">/</span>
          <button onClick={() => navigate({ name: "products" })} className="hover:text-energum-blue">Produits</button>
          <span className="mx-2">/</span>
          <span className="font-semibold text-energum-blue">{product.name}</span>
        </div>
      </div>

      <div className="mx-auto grid max-w-7xl gap-12 px-4 py-12 sm:px-6 lg:grid-cols-2 lg:px-8">
        {/* Visual */}
        <div
          className={`relative flex items-center justify-center overflow-hidden rounded-3xl p-10 ${
            isOrange ? "bg-gradient-to-br from-orange-100 via-orange-200 to-orange-300" : "bg-gradient-to-br from-blue-100 via-blue-200 to-blue-300"
          }`}
        >
          <div className="absolute inset-0 opacity-30">
            <div className={`absolute h-72 w-72 rounded-full blur-3xl ${isOrange ? "bg-orange-500" : "bg-blue-500"}`} style={{ top: "10%", left: "10%" }} />
          </div>
          <div className="relative animate-float-slow">
            <ProductBottle variant={product.color} label={product.slug.toUpperCase()} size={280} />
          </div>
        </div>

        {/* Info */}
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-energum-orange">
            <span>{isOrange ? "☀️ FORMULE JOUR" : "🌙 FORMULE NUIT"}</span>
            <span>·</span>
            <span>60 gummies</span>
          </div>
          <h1 className="mt-2 text-4xl font-extrabold text-energum-blue sm:text-5xl">{product.name}</h1>
          <p className="mt-3 text-lg text-slate-600">{product.tagline}</p>

          <div className="mt-3 flex items-center gap-2 text-sm">
            <span className="text-energum-amber">{"★".repeat(Math.round(product.rating))}</span>
            <span className="font-bold text-slate-900">{product.rating}/5</span>
            <span className="text-slate-500">· {product.reviews} avis vérifiés</span>
          </div>

          <p className="mt-5 text-slate-700">{product.description}</p>

          <div className="mt-6 flex items-end gap-3">
            <span className="text-4xl font-extrabold text-energum-blue">{product.price} MAD</span>
            {product.oldPrice && (
              <>
                <span className="text-xl text-slate-400 line-through">{product.oldPrice} MAD</span>
                <span className="rounded-full bg-rose-100 px-2 py-0.5 text-xs font-bold text-rose-600">
                  -{Math.round((1 - product.price / product.oldPrice) * 100)}%
                </span>
              </>
            )}
          </div>
          <div className="mt-1 text-xs text-slate-500">Soit {(product.price / product.capsules).toFixed(2)} MAD par gummy</div>

          <div className="mt-6 flex items-center gap-3">
            <div className="flex items-center rounded-full border border-slate-300 bg-white">
              <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="px-4 py-2 text-lg font-bold text-slate-700">−</button>
              <span className="w-10 text-center font-bold">{qty}</span>
              <button onClick={() => setQty((q) => q + 1)} className="px-4 py-2 text-lg font-bold text-slate-700">+</button>
            </div>
            <button
              onClick={() => add(product.id, qty)}
              className={`flex-1 rounded-full px-6 py-3.5 text-sm font-bold text-white shadow-xl transition hover:brightness-110 ${
                isOrange ? "bg-gradient-to-r from-energum-orange to-energum-amber shadow-orange-500/30" : "bg-gradient-to-r from-energum-blue to-blue-700 shadow-blue-500/30"
              }`}
            >
              + Ajouter au panier
            </button>
          </div>

          <button
            onClick={() => { add(product.id, qty); navigate({ name: "checkout" }); }}
            className="mt-3 w-full rounded-full border-2 border-energum-blue px-6 py-3 text-sm font-bold text-energum-blue hover:bg-energum-blue hover:text-white"
          >
            Acheter maintenant
          </button>

          <div className="mt-6 grid grid-cols-3 gap-3 text-center text-xs">
            {[
              { i: "🚚", t: "Livraison gratuite" },
              { i: "🔄", t: "Satisfait ou remboursé 30j" },
              { i: "🇫🇷", t: "Fabriqué en France" },
            ].map((b) => (
              <div key={b.t} className="rounded-2xl border border-slate-200 bg-white p-3">
                <div className="text-2xl">{b.i}</div>
                <div className="mt-1 font-semibold text-slate-700">{b.t}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* RITUEL INTERACTIF — Creative usage section */}
      <div className="mx-auto max-w-7xl px-4 pb-10 sm:px-6 lg:px-8">
        <div
          className={`relative overflow-hidden rounded-3xl p-8 text-white shadow-2xl cursor-pointer transition hover:scale-[1.01] ${
            isOrange
              ? "bg-gradient-to-br from-orange-500 via-orange-600 to-orange-700"
              : "bg-gradient-to-br from-energum-blue via-blue-800 to-energum-blue-deep"
          }`}
          onClick={() => setShowRituel((v) => !v)}
        >
          <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/10 blur-2xl" />
          <div className="absolute -left-10 bottom-0 h-32 w-32 rounded-full bg-white/10 blur-2xl" />

          <div className="relative flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest opacity-80">
                <span>✨ Cliquez pour découvrir</span>
              </div>
              <h2 className="mt-1 text-2xl font-extrabold">Votre rituel {product.slug === "focus" ? "du matin" : "du soir"}</h2>
              <p className="mt-1 text-sm opacity-90">
                {showRituel ? "Cliquez pour réduire" : "Comment utiliser ENERGUM " + product.slug.toUpperCase() + " au quotidien ?"}
              </p>
            </div>
            <div className={`text-3xl transition-transform ${showRituel ? "rotate-180" : ""}`}>▼</div>
          </div>

          {showRituel && (
            <div className="relative mt-8 grid gap-6 md:grid-cols-3">
              {product.slug === "focus" ? (
                <>
                  <RituelStep
                    n="1"
                    icon="🌅"
                    title="Au réveil"
                    desc="Prenez 2 gummies FOCUS avec votre petit-déjeuner et un grand verre d'eau."
                    time="7h – 9h"
                  />
                  <RituelStep
                    n="2"
                    icon="💧"
                    title="Hydratation"
                    desc="Buvez 1,5 L d'eau dans la journée pour optimiser l'absorption des actifs."
                    time="Toute la journée"
                  />
                  <RituelStep
                    n="3"
                    icon="🎯"
                    title="Performance"
                    desc="Profitez de 6 à 8h de concentration soutenue sans pic ni crash."
                    time="Effet progressif"
                  />
                </>
              ) : (
                <>
                  <RituelStep
                    n="1"
                    icon="🌙"
                    title="30 min avant le coucher"
                    desc="Prenez 2 gummies SOMMEIL avec un verre d'eau tiède."
                    time="22h – 23h"
                  />
                  <RituelStep
                    n="2"
                    icon="📵"
                    title="Déconnexion"
                    desc="Évitez les écrans bleu. Lisez ou méditez pour préparer votre cerveau."
                    time="Routine du soir"
                  />
                  <RituelStep
                    n="3"
                    icon="💤"
                    title="Sommeil profond"
                    desc="Endormissement en ~18 min. Réveil frais et récupéré, sans grogginess."
                    time="Toute la nuit"
                  />
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 lg:px-8">
        <div className="overflow-hidden rounded-3xl bg-white shadow-md ring-1 ring-slate-200">
          <div className="flex flex-wrap gap-1 border-b border-slate-200 bg-slate-50 p-2">
            {[
              { k: "description", l: "Description" },
              { k: "ingredients", l: "Ingrédients" },
              { k: "usage", l: "Posologie" },
              { k: "avis", l: `Avis (${productReviews.length})` },
            ].map((t) => (
              <button
                key={t.k}
                onClick={() => setTab(t.k as typeof tab)}
                className={`rounded-full px-5 py-2 text-sm font-semibold transition ${
                  tab === t.k ? "bg-energum-blue text-white shadow" : "text-slate-600 hover:bg-white"
                }`}
              >
                {t.l}
              </button>
            ))}
          </div>
          <div className="p-6 sm:p-8">
            {tab === "description" && (
              <div className="max-w-none text-slate-700">
                <p className="text-lg">{product.longDescription}</p>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  {product.benefits.map((b) => (
                    <button
                      key={b.title}
                      onClick={() => setExpandedBenefit(expandedBenefit === b.title ? null : b.title)}
                      className={`flex items-start gap-3 rounded-2xl p-4 text-left transition ${
                        expandedBenefit === b.title
                          ? isOrange ? "bg-orange-50 ring-2 ring-orange-200" : "bg-blue-50 ring-2 ring-blue-200"
                          : "bg-slate-50 hover:bg-slate-100"
                      }`}
                    >
                      <span className="text-2xl">{b.icon}</span>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <div className={`font-bold ${isOrange ? "text-orange-700" : "text-energum-blue"}`}>{b.title}</div>
                          <span className="text-xs text-slate-400">{expandedBenefit === b.title ? "▲" : "▼"}</span>
                        </div>
                        <div className="text-sm text-slate-600">{b.desc}</div>
                        {expandedBenefit === b.title && (
                          <div className="mt-3 rounded-xl bg-white p-3 text-xs text-slate-600 shadow-sm">
                            {b.title.includes("Concentration")
                              ? "La synergie Bacopa + L-Théanine + caféine naturelle soutient l'attention soutenue sans effet rebond."
                              : b.title.includes("Clarté")
                              ? "Réduction du brouillard cognitif grâce à l'amélioration de la microcirculation cérébrale (Ginkgo Biloba)."
                              : b.title.includes("Mémoire")
                              ? "La plasticité synaptique est favorisée par le BDNF induit par le Bacopa Monnieri."
                              : b.title.includes("fatigue")
                              ? "La Rhodiola Rosea module l'axe HPA et réduit le cortisol chronique."
                              : b.title.includes("Endormissement")
                              ? "La mélatonine micro-dosée (1.9 mg) resynchronise l'horloge circadienne naturellement."
                              : b.title.includes("Sommeil")
                              ? "Le magnésium bisglycinate améliore la qualité du sommeil profond (ondes delta)."
                              : b.title.includes("Réveil")
                              ? "Sans effet hypnotique fort : réveil naturel sans grogginess ni accoutumance."
                              : "La Passiflore et la Valériane apaisent le système nerveux central par voie GABAergique."}
                          </div>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {tab === "ingredients" && (
              <div>
                <p className="mb-4 text-sm text-slate-600">Composition par dose journalière (2 gummies) :</p>
                <div className="space-y-3">
                  {product.ingredients.map((i) => (
                    <button
                      key={i.name}
                      onClick={() => setExpandedIngredient(expandedIngredient === i.name ? null : i.name)}
                      className={`w-full rounded-2xl border p-4 text-left transition ${
                        expandedIngredient === i.name
                          ? isOrange ? "border-orange-300 bg-orange-50" : "border-blue-300 bg-blue-50"
                          : "border-slate-200 bg-white hover:bg-slate-50"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className={`grid h-8 w-8 place-items-center rounded-full text-xs font-bold text-white ${isOrange ? "bg-orange-500" : "bg-energum-blue"}`}>
                            {i.name.charAt(0)}
                          </span>
                          <div>
                            <div className="font-bold text-energum-blue">{i.name}</div>
                            <div className="text-xs text-slate-500">{i.dose}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-slate-600">{i.role}</span>
                          <span className="text-xs text-slate-400">{expandedIngredient === i.name ? "▲" : "▼"}</span>
                        </div>
                      </div>
                      {expandedIngredient === i.name && (
                        <div className="mt-3 rounded-xl bg-white p-4 text-sm text-slate-700 shadow-sm">
                          <strong className={isOrange ? "text-orange-700" : "text-energum-blue"}>Rôle détaillé :</strong>{" "}
                          {i.name === "Bacopa Monnieri"
                            ? "Herbe ayurvédique traditionnelle. Améliore la vitesse de traitement visuel, la mémoire de travail et la rétention à long terme après 8-12 semaines d'utilisation régulière."
                            : i.name === "L-Théanine"
                            ? "Acide aminé du thé vert. Induit des ondes alpha cérébrales (8-13 Hz) associées à un état de relaxation alerte. Réduit l'anxiété liée à la caféine."
                            : i.name === "Ginkgo Biloba"
                            ? "Arbre millénaire. Améliore la microcirculation cérébrale et la perfusion sanguine, soutenant l'oxygénation des neurones."
                            : i.name === "Rhodiola Rosea"
                            ? "Adaptogène arctique. Réduit la fatigue physique et mentale induite par le stress. Module la sérotonine et les catécholamines."
                            : i.name.includes("Vitamine B")
                            ? "Cofacteurs essentiels de la méthylation et de la synthèse des neurotransmetteurs (dopamine, sérotonine, GABA, acétylcholine)."
                            : i.name.includes("Caféine")
                            ? "Caféine naturelle du guarana à libération lente. 75 mg = ~1 expresso. Synergie optimale avec la L-Théanine."
                            : i.name === "Mélatonine"
                            ? "Hormone du sommeil sécrétée par la glande pinéale. Dose physiologique de 1.9 mg pour resynchroniser le rythme circadien sans effet de dépendance."
                            : i.name.includes("Magnésium")
                            ? "Forme chélatée bisglycinate : biodisponibilité supérieure à 80%. Module les récepteurs NMDA et GABA-A pour une détente neuromusculaire."
                            : i.name === "Valériane"
                            ? "Racine médicinale européenne. Augmente la disponibilité du GABA dans le système nerveux central. Effet somnifère doux sans accoutumance."
                            : i.name === "Passiflore"
                            ? "Plante américaine traditionnelle. Synergie GABAergique avec la Valériane. Réduit l'hyperactivité mentale du soir."
                            : i.name === "Camomille"
                            ? "Fleur apaisante riche en apigénine. Lie les récepteurs benzodiazépines du cerveau pour une relaxation naturelle."
                            : "Ingrédient actif essentiel de la formule ENERGUM."}
                        </div>
                      )}
                    </button>
                  ))}
                </div>
                <div className="mt-4 rounded-2xl bg-amber-50 p-4 text-sm text-amber-900">
                  <strong>Excipients :</strong> pectine de fruits, sirop de glucose bio, jus de fruits concentré, arômes naturels. Sans gélatine animale, sans colorants artificiels.
                </div>
              </div>
            )}

            {tab === "usage" && (
              <div className="space-y-4 text-slate-700">
                <div className="rounded-2xl bg-emerald-50 p-5">
                  <div className="mb-1 text-xs font-bold uppercase tracking-wider text-emerald-700">Posologie</div>
                  <p className="text-base">{product.usage}</p>
                </div>
                <div className="rounded-2xl bg-rose-50 p-5">
                  <div className="mb-1 text-xs font-bold uppercase tracking-wider text-rose-700">Précautions</div>
                  <p className="text-base">{product.warnings}</p>
                </div>
                <div className="rounded-2xl bg-slate-50 p-5">
                  <div className="mb-1 text-xs font-bold uppercase tracking-wider text-slate-600">Conservation</div>
                  <p className="text-base">À conserver à l'abri de la chaleur, de l'humidité et de la lumière. Tenir hors de portée des enfants.</p>
                </div>
              </div>
            )}

            {tab === "avis" && (
              <div className="space-y-4">
                {productReviews.map((r) => (
                  <div key={r.id} className="rounded-2xl border border-slate-200 p-5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <span className="grid h-10 w-10 place-items-center rounded-full bg-energum-blue text-sm font-bold text-white">
                          {r.author.charAt(0)}
                        </span>
                        <div>
                          <div className="font-bold text-slate-900">{r.author}</div>
                          <div className="text-xs text-slate-500">{new Date(r.date).toLocaleDateString("fr-FR")}</div>
                        </div>
                      </div>
                      <div className="text-energum-amber">{"★".repeat(r.rating)}</div>
                    </div>
                    <h4 className="mt-3 font-bold text-energum-blue">{r.title}</h4>
                    <p className="mt-1 text-sm text-slate-700">{r.body}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function RituelStep({ n, icon, title, desc, time }: { n: string; icon: string; title: string; desc: string; time: string }) {
  return (
    <div className="relative rounded-2xl border border-white/20 bg-white/10 p-5 backdrop-blur">
      <div className="absolute -top-3 -right-3 grid h-8 w-8 place-items-center rounded-full bg-energum-amber text-sm font-extrabold text-energum-blue-deep">
        {n}
      </div>
      <div className="text-3xl">{icon}</div>
      <h3 className="mt-2 text-base font-bold">{title}</h3>
      <p className="mt-1 text-sm opacity-90">{desc}</p>
      <div className="mt-3 inline-block rounded-full bg-white/20 px-3 py-1 text-xs font-bold">{time}</div>
    </div>
  );
}
