import { useState } from "react";
import { products } from "../data/products";
import { useAuth, useCart, useRouter } from "../store";

export default function Checkout() {
  const { items, clear, count } = useCart();
  const { user } = useAuth();
  const { navigate } = useRouter();
  const [done, setDone] = useState(false);
  const [orderId] = useState(() => "EN-" + Math.random().toString(36).slice(2, 8).toUpperCase());

  const enriched = items
    .map((i) => ({ item: i, product: products.find((p) => p.id === i.productId)! }))
    .filter((x) => x.product);
  const subtotal = enriched.reduce((s, { item, product }) => s + item.quantity * product.price, 0);
  const shipping = 0;
  const total = subtotal + shipping;

  if (count === 0 && !done) {
    return (
      <div className="bg-slate-50 py-20 text-center">
        <p className="text-slate-600">Votre panier est vide.</p>
        <button onClick={() => navigate({ name: "products" })} className="mt-4 rounded-full bg-energum-blue px-6 py-2 text-white">
          Voir les produits
        </button>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="bg-slate-50 py-20">
        <div className="mx-auto max-w-md px-4 text-center">
          <div className="text-5xl">🔐</div>
          <h1 className="mt-3 text-2xl font-extrabold text-energum-blue">Connectez-vous pour continuer</h1>
          <p className="mt-2 text-slate-600">Suivi de commande, historique et offres réservées aux membres.</p>
          <div className="mt-5 flex justify-center gap-3">
            <button onClick={() => navigate({ name: "login" })} className="rounded-full bg-energum-blue px-6 py-2.5 text-sm font-bold text-white">
              Connexion
            </button>
            <button onClick={() => navigate({ name: "register" })} className="rounded-full bg-energum-orange px-6 py-2.5 text-sm font-bold text-white">
              S'inscrire
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (done) {
    return (
      <div className="bg-slate-50 py-20">
        <div className="mx-auto max-w-xl rounded-3xl bg-white p-10 text-center shadow-xl ring-1 ring-slate-200">
          <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-emerald-100 text-3xl">✓</div>
          <h1 className="mt-4 text-3xl font-extrabold text-energum-blue">Commande confirmée !</h1>
          <p className="mt-2 text-slate-600">Merci {user.fullName.split(" ")[0]}, votre commande <strong>#{orderId}</strong> a bien été enregistrée.</p>
          <p className="mt-1 text-sm text-slate-500">Un email de confirmation a été envoyé à {user.email}.</p>
          <button onClick={() => navigate({ name: "home" })} className="mt-6 rounded-full bg-energum-blue px-6 py-3 text-sm font-bold text-white">
            Retour à l'accueil
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-50 py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-extrabold text-energum-blue sm:text-4xl">Validation de la commande</h1>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            clear();
            setDone(true);
          }}
          className="mt-8 grid gap-8 lg:grid-cols-3"
        >
          <div className="space-y-6 lg:col-span-2">
            <Section title="Adresse de livraison">
              <div className="grid gap-4 sm:grid-cols-2">
                <Input label="Prénom" defaultValue={user.fullName.split(" ")[0]} />
                <Input label="Nom" defaultValue={user.fullName.split(" ").slice(1).join(" ")} />
                <Input label="Adresse" full />
                <Input label="Code postal" />
                <Input label="Ville" />
                <Input label="Téléphone" type="tel" />
              </div>
            </Section>

            <Section title="Mode de livraison">
              <div className="space-y-2">
                {[
                  { i: "🚚", t: "Standard 48h", p: "Gratuite", d: true },
                  { i: "⚡", t: "Express 24h", p: "Gratuite" },
                ].map((o, i) => (
                  <label key={i} className="flex cursor-pointer items-center justify-between rounded-2xl border border-slate-200 p-4 has-[:checked]:border-energum-blue has-[:checked]:bg-energum-blue/5">
                    <div className="flex items-center gap-3">
                      <input type="radio" name="ship" defaultChecked={o.d} className="h-4 w-4 accent-energum-blue" />
                      <span className="text-xl">{o.i}</span>
                      <span className="font-semibold text-slate-800">{o.t}</span>
                    </div>
                    <span className="font-bold text-energum-blue">{o.p}</span>
                  </label>
                ))}
              </div>
            </Section>

            <Section title="Paiement">
              <div className="grid gap-4 sm:grid-cols-2">
                <Input label="Numéro de carte" placeholder="0000 0000 0000 0000" full />
                <Input label="Date d'expiration" placeholder="MM/AA" />
                <Input label="CVV" placeholder="123" />
              </div>
              <div className="mt-3 text-xs text-slate-500">🔒 Paiement 100% sécurisé · Démonstration uniquement.</div>
            </Section>
          </div>

          <aside className="h-fit rounded-3xl bg-white p-6 shadow-md ring-1 ring-slate-200">
            <h3 className="text-lg font-bold text-energum-blue">Votre commande</h3>
            <ul className="mt-4 space-y-2 text-sm">
              {enriched.map(({ item, product }) => (
                <li key={product.id} className="flex justify-between">
                  <span className="text-slate-700">{product.name} × {item.quantity}</span>
                  <span className="font-semibold">{product.price * item.quantity} MAD</span>
                </li>
              ))}
            </ul>
            <div className="mt-3 space-y-1 border-t border-slate-200 pt-3 text-sm">
              <div className="flex justify-between"><span className="text-slate-600">Sous-total</span><span>{subtotal} MAD</span></div>
              <div className="flex justify-between"><span className="text-slate-600">Livraison</span><span>Offerte</span></div>
              <div className="flex items-baseline justify-between border-t border-slate-200 pt-2">
                <span className="text-base font-bold text-energum-blue">Total</span>
                <span className="text-2xl font-extrabold text-energum-blue">{total} MAD</span>
              </div>
            </div>
            <button className="mt-5 w-full rounded-full bg-gradient-to-r from-energum-orange to-energum-amber py-3 text-sm font-bold text-white shadow-lg hover:brightness-110">
              Confirmer la commande
            </button>
          </aside>
        </form>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
      <h2 className="mb-4 text-lg font-bold text-energum-blue">{title}</h2>
      {children}
    </div>
  );
}

function Input({ label, full, ...rest }: { label: string; full?: boolean } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className={`block ${full ? "sm:col-span-2" : ""}`}>
      <span className="mb-1 block text-xs font-bold uppercase tracking-wider text-slate-600">{label}</span>
      <input
        required
        {...rest}
        className="w-full rounded-xl border border-slate-300 bg-white px-3 py-2.5 text-sm outline-none focus:border-energum-blue focus:ring-2 focus:ring-energum-blue/20"
      />
    </label>
  );
}
