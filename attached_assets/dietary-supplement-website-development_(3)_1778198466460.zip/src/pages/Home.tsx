import ProductBottle from "../components/ProductBottle";
import { products } from "../data/products";
import { useCart, useRouter } from "../store";

export default function Home() {
  const { navigate } = useRouter();
  const { add } = useCart();

  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden bg-radial-blue text-white">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute -left-32 top-20 h-96 w-96 rounded-full bg-blue-500/30 blur-3xl" />
          <div className="absolute right-0 top-1/2 h-96 w-96 rounded-full bg-orange-500/20 blur-3xl" />
        </div>

        <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:px-8 lg:py-24">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider backdrop-blur">
              <span className="h-2 w-2 rounded-full bg-emerald-400" />
              Nouveau · Formule brevetée 2026
            </span>
            <h1 className="mt-5 text-4xl font-extrabold leading-[1.05] tracking-tight text-shadow-soft sm:text-5xl lg:text-6xl">
              ÉNERGIE LE JOUR.<br />
              <span className="text-energum-amber">RÉCUPÉRATION</span> LA NUIT.
            </h1>
            <p className="mt-5 max-w-xl text-lg text-blue-100/90">
              Deux formules naturelles pour un équilibre parfait. <strong>FOCUS</strong> pour la concentration et la performance, <strong>SOMMEIL</strong> pour une nuit profonde et réparatrice.
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              <button
                onClick={() => navigate({ name: "products" })}
                className="rounded-full bg-gradient-to-r from-energum-orange to-energum-amber px-7 py-3.5 text-sm font-bold text-white shadow-xl shadow-orange-500/40 transition hover:scale-[1.02] hover:brightness-110"
              >
                Découvrir les produits →
              </button>
              <button
                onClick={() => navigate({ name: "science" })}
                className="rounded-full border border-white/30 bg-white/5 px-7 py-3.5 text-sm font-semibold text-white backdrop-blur transition hover:bg-white/10"
              >
                La science derrière
              </button>
            </div>

            <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-4">
              {[
                { v: "100%", l: "Naturel" },
                { v: "Vegan", l: "Certifié" },
                { v: "0g", l: "Gluten" },
                { v: "0", l: "OGM" },
              ].map((s) => (
                <div key={s.l} className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center backdrop-blur">
                  <div className="text-xl font-extrabold text-energum-amber">{s.v}</div>
                  <div className="text-xs uppercase tracking-wider text-blue-100/80">{s.l}</div>
                </div>
              ))}
            </div>
          </div>

          {/* visual */}
          <div className="relative flex items-center justify-center">
            <div className="absolute inset-0 grid place-items-center">
              <div className="h-72 w-72 rounded-full bg-gradient-to-br from-orange-500/30 to-blue-500/30 blur-3xl" />
            </div>
            <div className="relative flex items-end gap-4 sm:gap-8">
              <div className="animate-float-slow">
                <ProductBottle variant="orange" label="FOCUS" size={180} />
              </div>
              <div className="animate-float-slow [animation-delay:1.5s]">
                <ProductBottle variant="blue" label="SOMMEIL" size={180} />
              </div>
            </div>
          </div>
        </div>

        {/* trust strip */}
        <div className="relative border-t border-white/10 bg-black/20 backdrop-blur">
          <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-around gap-4 px-4 py-4 text-center text-xs font-semibold uppercase tracking-wider text-blue-100/90 sm:text-sm">
            {[
              { i: "🌿", t: "Ingrédients Naturels" },
              { i: "🌾", t: "Sans Gluten" },
              { i: "🍃", t: "Vegan" },
              { i: "🧪", t: "Sans OGM" },
              { i: "🇫🇷", t: "Fabriqué en France" },
            ].map((b) => (
              <div key={b.t} className="flex items-center gap-2">
                <span>{b.i}</span>
                <span>{b.t}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRODUCTS */}
      <section className="bg-gradient-to-b from-slate-50 to-white py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <span className="text-xs font-bold uppercase tracking-[0.2em] text-energum-orange">Nos formules</span>
            <h2 className="mt-2 text-3xl font-extrabold text-energum-blue sm:text-4xl">
              Deux formules. Un équilibre parfait.
            </h2>
            <p className="mt-4 text-slate-600">
              Conçues par des chercheurs en neurosciences et nutrition pour répondre aux deux besoins fondamentaux du cerveau : la performance et la récupération.
            </p>
          </div>

          <div className="mt-12 grid gap-8 lg:grid-cols-2">
            {products.map((p) => {
              const isOrange = p.color === "orange";
              return (
                <article
                  key={p.id}
                  className={`group relative overflow-hidden rounded-3xl p-8 text-white shadow-2xl transition hover:-translate-y-1 ${
                    isOrange
                      ? "bg-gradient-to-br from-orange-500 via-orange-600 to-orange-700"
                      : "bg-gradient-to-br from-energum-blue via-energum-blue-deep to-blue-950"
                  }`}
                >
                  <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-white/10 blur-3xl" />
                  <div className="relative flex flex-col items-start gap-6 sm:flex-row">
                    <div className="shrink-0">
                      <ProductBottle variant={p.color} label={p.slug.toUpperCase()} size={150} />
                    </div>
                    <div className="flex-1">
                      <div className="mb-2 flex items-center gap-2 text-xs font-bold uppercase tracking-widest opacity-80">
                        <span>{isOrange ? "☀️ JOUR" : "🌙 NUIT"}</span>
                      </div>
                      <h3 className="text-2xl font-extrabold">{p.name}</h3>
                      <p className="mt-2 text-sm opacity-90">{p.tagline}</p>

                      <ul className="mt-4 space-y-1.5 text-sm">
                        {p.benefits.slice(0, 3).map((b) => (
                          <li key={b.title} className="flex items-center gap-2 opacity-95">
                            <span>{b.icon}</span>
                            <span>{b.title}</span>
                          </li>
                        ))}
                      </ul>

                      <div className="mt-5 flex items-end gap-3">
                        <span className="text-3xl font-extrabold">{p.price} MAD</span>
                        {p.oldPrice && <span className="text-base line-through opacity-60">{p.oldPrice} MAD</span>}
                      </div>

                      <div className="mt-5 flex flex-wrap gap-2">
                        <button
                          onClick={() => navigate({ name: "product", slug: p.slug })}
                          className="rounded-full bg-white/15 px-5 py-2.5 text-sm font-semibold backdrop-blur hover:bg-white/25"
                        >
                          En savoir plus
                        </button>
                        <button
                          onClick={() => add(p.id)}
                          className={`rounded-full px-5 py-2.5 text-sm font-bold shadow-lg ${
                            isOrange ? "bg-white text-orange-600 hover:brightness-95" : "bg-energum-amber text-energum-blue-deep hover:brightness-110"
                          }`}
                        >
                          + Ajouter au panier
                        </button>
                      </div>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="bg-energum-blue-deep py-20 text-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <span className="text-xs font-bold uppercase tracking-[0.2em] text-energum-amber">Comment ça marche</span>
            <h2 className="mt-2 text-3xl font-extrabold sm:text-4xl">Un protocole en 3 étapes</h2>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {[
              { n: "01", t: "Le matin — FOCUS", d: "2 gummies au petit-déjeuner pour activer concentration et énergie cognitive durant 6 à 8 h." },
              { n: "02", t: "La journée — Hydratation", d: "Buvez 1,5 L d'eau pour optimiser l'absorption des principes actifs et la microcirculation." },
              { n: "03", t: "Le soir — SOMMEIL", d: "2 gummies 30 min avant le coucher pour un endormissement rapide et profond." },
            ].map((s) => (
              <div key={s.n} className="relative rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur">
                <div className="text-5xl font-black text-energum-amber/40">{s.n}</div>
                <h3 className="mt-2 text-lg font-bold">{s.t}</h3>
                <p className="mt-2 text-sm text-blue-100/80">{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="bg-white py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <span className="text-xs font-bold uppercase tracking-[0.2em] text-energum-orange">Avis clients</span>
            <h2 className="mt-2 text-3xl font-extrabold text-energum-blue sm:text-4xl">
              + de 12 000 clients satisfaits
            </h2>
            <div className="mt-3 flex items-center justify-center gap-2 text-sm">
              <div className="text-energum-amber">★★★★★</div>
              <span className="font-bold text-slate-900">4.9/5</span>
              <span className="text-slate-500">basé sur 2 229 avis vérifiés</span>
            </div>
          </div>
          <div className="mt-10 grid gap-5 md:grid-cols-3">
            {[
              { n: "Yasmine B.", c: "Étudiante Master", r: 5, t: "FOCUS m'a sauvé pendant mon mémoire. 5h de lecture sans décrocher." },
              { n: "Hicham A.", c: "Ingénieur", r: 5, t: "Je m'endors en 15 min, fini le café à 23h pour m'aider à dormir (oui c'est paradoxal). " },
              { n: "Léa P.", c: "Sportive", r: 5, t: "+25% de sommeil profond confirmé par ma montre. Récupération nette." },
            ].map((t, i) => (
              <div key={i} className="rounded-3xl border border-slate-200 bg-slate-50 p-6 transition hover:shadow-lg">
                <div className="text-energum-amber">{"★".repeat(t.r)}</div>
                <p className="mt-3 text-slate-700">"{t.t}"</p>
                <div className="mt-4 flex items-center gap-3 border-t border-slate-200 pt-4">
                  <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-energum-orange to-energum-amber text-sm font-bold text-white">
                    {t.n.charAt(0)}
                  </span>
                  <div>
                    <div className="text-sm font-bold text-slate-900">{t.n}</div>
                    <div className="text-xs text-slate-500">{t.c}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative overflow-hidden bg-gradient-to-r from-energum-orange to-energum-amber py-16 text-white">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 px-4 text-center sm:px-6 lg:flex-row lg:px-8 lg:text-left">
          <div>
            <h2 className="text-3xl font-extrabold sm:text-4xl">Vivez votre meilleure version.</h2>
            <p className="mt-2 text-white/90">Le pack DUO Focus + Sommeil à -20% pendant 48h.</p>
          </div>
          <button
            onClick={() => navigate({ name: "products" })}
            className="rounded-full bg-white px-8 py-4 text-base font-extrabold text-energum-orange shadow-xl transition hover:scale-105"
          >
            Profiter de l'offre →
          </button>
        </div>
      </section>
    </div>
  );
}
