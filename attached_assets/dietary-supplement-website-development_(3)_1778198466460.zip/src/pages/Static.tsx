import { useState } from "react";

export function Science() {
  return (
    <div className="bg-slate-50">
      <div className="bg-radial-blue py-16 text-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <span className="text-xs font-bold uppercase tracking-[0.2em] text-energum-amber">La science</span>
          <h1 className="mt-2 text-4xl font-extrabold sm:text-5xl">La rigueur scientifique au service de votre équilibre.</h1>
          <p className="mt-4 max-w-3xl text-blue-100/90">
            ENERGUM est né d'un travail de recherche en master spécialisé en neurosciences et nutrition cellulaire. Chaque ingrédient, chaque dosage, chaque association a été étudiée pour son efficacité documentée.
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-3">
          {[
            { i: "🔬", t: "Études cliniques", d: "Plus de 150 publications PubMed analysées pour valider chaque actif." },
            { i: "⚗️", t: "Dosages efficaces", d: "Doses thérapeutiques (et non sub-thérapeutiques marketing)." },
            { i: "🧬", t: "Biodisponibilité", d: "Formes brevetées (bisglycinate, micro-encapsulation)." },
          ].map((c) => (
            <div key={c.t} className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
              <div className="text-4xl">{c.i}</div>
              <h3 className="mt-3 text-lg font-bold text-energum-blue">{c.t}</h3>
              <p className="mt-2 text-sm text-slate-600">{c.d}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 grid gap-8 lg:grid-cols-2">
          <div className="rounded-3xl bg-gradient-to-br from-orange-500 to-orange-700 p-8 text-white shadow-xl">
            <h3 className="text-2xl font-extrabold">FOCUS — Mécanismes d'action</h3>
            <ul className="mt-4 space-y-2 text-sm">
              <li>• <strong>Bacopa Monnieri</strong> : module l'expression de BDNF, soutient la plasticité synaptique.</li>
              <li>• <strong>L-Théanine</strong> : induit des ondes alpha, focus calme sans tension.</li>
              <li>• <strong>Rhodiola</strong> : régule l'axe HPA, réduit le cortisol chronique.</li>
              <li>• <strong>B-complex</strong> : cofacteurs de la méthylation et synthèse des neurotransmetteurs.</li>
            </ul>
          </div>
          <div className="rounded-3xl bg-gradient-to-br from-energum-blue to-energum-blue-deep p-8 text-white shadow-xl">
            <h3 className="text-2xl font-extrabold">SOMMEIL — Mécanismes d'action</h3>
            <ul className="mt-4 space-y-2 text-sm">
              <li>• <strong>Mélatonine 1.9 mg</strong> : dose physiologique pour resynchroniser l'horloge biologique.</li>
              <li>• <strong>Magnésium bisglycinate</strong> : module les récepteurs NMDA et GABA.</li>
              <li>• <strong>Valériane + Passiflore</strong> : synergie GABAergique sans effet hypnotique fort.</li>
              <li>• <strong>B6</strong> : cofacteur de la conversion sérotonine → mélatonine.</li>
            </ul>
          </div>
        </div>

        <div className="mt-12 rounded-3xl bg-white p-8 shadow-sm ring-1 ring-slate-200">
          <h3 className="text-2xl font-extrabold text-energum-blue">Notre engagement qualité</h3>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { t: "Fabriqué en France", d: "Laboratoire ISO 22000" },
              { t: "Tests tiers", d: "Pureté & métaux lourds" },
              { t: "Traçabilité totale", d: "Du champ au flacon" },
              { t: "Sans artifices", d: "Ni colorants, ni édulcorants" },
            ].map((q) => (
              <div key={q.t} className="rounded-2xl border border-slate-200 p-4">
                <div className="font-bold text-energum-blue">{q.t}</div>
                <div className="text-sm text-slate-600">{q.d}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export function About() {
  return (
    <div className="bg-slate-50">
      <div className="bg-radial-blue py-16 text-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <span className="text-xs font-bold uppercase tracking-[0.2em] text-energum-amber">À propos</span>
          <h1 className="mt-2 text-4xl font-extrabold sm:text-5xl">Un projet né en master de recherche.</h1>
          <p className="mt-4 max-w-3xl text-blue-100/90">
            ENERGUM est le fruit d'années de recherche en neurosciences appliquées. Notre mission : démocratiser des compléments efficaces, transparents et accessibles.
          </p>
        </div>
      </div>

      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:px-8">
        <div>
          <h2 className="text-3xl font-extrabold text-energum-blue">Notre histoire</h2>
          <p className="mt-4 text-slate-700 leading-relaxed">
            Tout commence en master, durant la rédaction d'un mémoire sur la fatigue cognitive et la dette de sommeil. Constat : les étudiants, chercheurs et professionnels exigeants disposent de très peu de solutions <em>réellement formulées sur la science</em>.
          </p>
          <p className="mt-3 text-slate-700 leading-relaxed">
            ENERGUM a été pensé comme un outil de performance durable : énergie le jour, récupération la nuit. Sans accoutumance, sans pic, sans mauvais réveil.
          </p>
          <div className="mt-6 grid grid-cols-3 gap-3 text-center">
            {[
              { v: "2 ans", l: "de R&D" },
              { v: "12k+", l: "clients" },
              { v: "4.9★", l: "satisfaction" },
            ].map((s) => (
              <div key={s.l} className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-200">
                <div className="text-2xl font-extrabold text-energum-orange">{s.v}</div>
                <div className="text-xs uppercase tracking-wider text-slate-500">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-3xl bg-gradient-to-br from-energum-blue to-energum-blue-deep p-8 text-white shadow-xl">
          <h3 className="text-2xl font-extrabold">Nos valeurs</h3>
          <ul className="mt-4 space-y-3">
            {[
              { t: "Transparence", d: "Composition complète, dosages publiés, sources tracées." },
              { t: "Efficacité", d: "Doses cliniques, formes biodisponibles, synergies validées." },
              { t: "Naturalité", d: "Vegan, sans gluten, sans OGM, sans colorants artificiels." },
              { t: "Éthique", d: "Approvisionnement responsable et packaging recyclable." },
            ].map((v) => (
              <li key={v.t}>
                <div className="font-bold text-energum-amber">{v.t}</div>
                <div className="text-sm text-blue-100/80">{v.d}</div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

export function Contact() {
  const [sent, setSent] = useState(false);
  return (
    <div className="bg-slate-50">
      <div className="bg-radial-blue py-16 text-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <span className="text-xs font-bold uppercase tracking-[0.2em] text-energum-amber">Contact</span>
          <h1 className="mt-2 text-4xl font-extrabold sm:text-5xl">Une question ? Parlons-en.</h1>
          <p className="mt-3 max-w-2xl text-blue-100/90">Notre équipe vous répond sous 24h ouvrées.</p>
        </div>
      </div>

      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-16 sm:px-6 lg:grid-cols-3 lg:px-8">
        <div className="space-y-4">
          {[
            { i: "✉️", t: "Email", d: "contact@energum.fr" },
            { i: "📞", t: "Téléphone", d: "+33 1 23 45 67 89" },
            { i: "📍", t: "Adresse", d: "12 rue de la Recherche, 75013 Paris" },
            { i: "🕒", t: "Horaires", d: "Lun – Ven · 9h – 18h" },
          ].map((c) => (
            <div key={c.t} className="rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
              <div className="flex items-start gap-3">
                <span className="text-2xl">{c.i}</span>
                <div>
                  <div className="font-bold text-energum-blue">{c.t}</div>
                  <div className="text-sm text-slate-600">{c.d}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="lg:col-span-2">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setSent(true);
            }}
            className="rounded-3xl bg-white p-8 shadow-md ring-1 ring-slate-200"
          >
            {sent ? (
              <div className="text-center">
                <div className="text-5xl">✅</div>
                <h3 className="mt-3 text-2xl font-extrabold text-energum-blue">Message envoyé !</h3>
                <p className="mt-2 text-slate-600">Nous vous répondrons sous 24h ouvrées.</p>
              </div>
            ) : (
              <>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="Nom complet" />
                  <Field label="Email" type="email" />
                  <Field label="Sujet" full />
                </div>
                <label className="mt-4 block">
                  <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-600">Message</span>
                  <textarea required rows={6} className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-energum-blue focus:ring-2 focus:ring-energum-blue/20" />
                </label>
                <button className="mt-5 w-full rounded-full bg-gradient-to-r from-energum-orange to-energum-amber py-3 text-sm font-bold text-white shadow-lg sm:w-auto sm:px-10">
                  Envoyer le message
                </button>
              </>
            )}
          </form>
        </div>
      </div>
    </div>
  );
}

function Field({ label, full, ...rest }: { label: string; full?: boolean } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className={`block ${full ? "sm:col-span-2" : ""}`}>
      <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-600">{label}</span>
      <input
        required
        {...rest}
        className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-energum-blue focus:ring-2 focus:ring-energum-blue/20"
      />
    </label>
  );
}
