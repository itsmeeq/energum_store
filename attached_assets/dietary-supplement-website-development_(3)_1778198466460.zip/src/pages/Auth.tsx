import { useState } from "react";
import Logo from "../components/Logo";
import { useAuth, useRouter } from "../store";

export function Login() {
  const { login } = useAuth();
  const { navigate } = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [showPwd, setShowPwd] = useState(false);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    const r = login(email, password);
    if (!r.ok) setErr(r.error || "Erreur");
    else navigate({ name: "account" });
  };

  return (
    <AuthShell title="Heureux de vous revoir 👋" subtitle="Connectez-vous à votre compte ENERGUM">
      <form onSubmit={onSubmit} className="space-y-4">
        <Field label="Email" value={email} onChange={setEmail} type="email" placeholder="vous@exemple.com" autoFocus />
        <Field
          label="Mot de passe"
          value={password}
          onChange={setPassword}
          type={showPwd ? "text" : "password"}
          placeholder="••••••••"
          rightAction={
            <button type="button" onClick={() => setShowPwd((v) => !v)} className="text-xs font-semibold text-energum-blue">
              {showPwd ? "Cacher" : "Afficher"}
            </button>
          }
        />
        {err && <div className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">{err}</div>}
        <button className="w-full rounded-full bg-gradient-to-r from-energum-blue to-blue-700 py-3 text-sm font-bold text-white shadow-lg hover:brightness-110">
          Se connecter
        </button>
      </form>
      <p className="mt-6 text-center text-sm text-slate-600">
        Pas encore de compte ?{" "}
        <button onClick={() => navigate({ name: "register" })} className="font-bold text-energum-orange hover:underline">
          Créer un compte
        </button>
      </p>
    </AuthShell>
  );
}

export function Register() {
  const { register } = useAuth();
  const { navigate } = useRouter();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [accept, setAccept] = useState(false);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    if (!accept) return setErr("Vous devez accepter les CGV.");
    if (password !== confirm) return setErr("Les mots de passe ne correspondent pas.");
    const r = register(fullName, email, password);
    if (!r.ok) setErr(r.error || "Erreur");
    else navigate({ name: "account" });
  };

  return (
    <AuthShell title="Créer un compte" subtitle="Rejoignez la communauté ENERGUM en 30 secondes">
      <form onSubmit={onSubmit} className="space-y-4">
        <Field label="Nom complet" value={fullName} onChange={setFullName} placeholder="Prénom Nom" autoFocus />
        <Field label="Email" value={email} onChange={setEmail} type="email" placeholder="vous@exemple.com" />
        <Field label="Mot de passe" value={password} onChange={setPassword} type="password" placeholder="6 caractères minimum" />
        <Field label="Confirmer le mot de passe" value={confirm} onChange={setConfirm} type="password" placeholder="••••••••" />
        <label className="flex items-start gap-2 text-xs text-slate-600">
          <input type="checkbox" checked={accept} onChange={(e) => setAccept(e.target.checked)} className="mt-0.5 h-4 w-4 accent-energum-orange" />
          <span>J'accepte les <a href="#" className="font-semibold text-energum-blue hover:underline">CGV</a> et la <a href="#" className="font-semibold text-energum-blue hover:underline">politique de confidentialité</a>.</span>
        </label>
        {err && <div className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700">{err}</div>}
        <button className="w-full rounded-full bg-gradient-to-r from-energum-orange to-energum-amber py-3 text-sm font-bold text-white shadow-lg hover:brightness-110">
          Créer mon compte
        </button>
      </form>
      <p className="mt-6 text-center text-sm text-slate-600">
        Déjà inscrit ?{" "}
        <button onClick={() => navigate({ name: "login" })} className="font-bold text-energum-blue hover:underline">
          Se connecter
        </button>
      </p>
    </AuthShell>
  );
}

function AuthShell({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  const { navigate } = useRouter();
  return (
    <div className="grid min-h-[calc(100vh-72px)] grid-cols-1 lg:grid-cols-2">
      <div className="relative hidden bg-radial-blue lg:block">
        <div className="absolute inset-0 flex flex-col justify-between p-12 text-white">
          <Logo size={48} />
          <div>
            <h2 className="text-4xl font-extrabold leading-tight">
              L'équilibre parfait,<br />
              <span className="text-energum-amber">jour et nuit.</span>
            </h2>
            <p className="mt-3 max-w-md text-blue-100/80">
              Accédez à votre espace personnel pour suivre vos commandes, vos cures, et bénéficier d'offres réservées aux membres.
            </p>
            <div className="mt-8 flex gap-2">
              {["🌿 Naturel", "🍃 Vegan", "🌾 Sans gluten", "🧪 Sans OGM"].map((t) => (
                <span key={t} className="rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-semibold backdrop-blur">
                  {t}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center bg-slate-50 px-4 py-12 sm:px-8">
        <div className="w-full max-w-md">
          <div className="mb-8 lg:hidden">
            <Logo size={40} variant="dark" />
          </div>
          <button
            onClick={() => navigate({ name: "home" })}
            className="mb-4 inline-flex items-center gap-1 text-sm text-slate-500 hover:text-energum-blue"
          >
            ← Retour à l'accueil
          </button>
          <h1 className="text-3xl font-extrabold text-energum-blue">{title}</h1>
          <p className="mt-2 text-slate-600">{subtitle}</p>
          <div className="mt-8 rounded-3xl bg-white p-6 shadow-xl ring-1 ring-slate-200 sm:p-8">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
  autoFocus,
  rightAction,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  placeholder?: string;
  autoFocus?: boolean;
  rightAction?: React.ReactNode;
}) {
  return (
    <label className="block">
      <div className="mb-1.5 flex items-center justify-between">
        <span className="text-xs font-bold uppercase tracking-wider text-slate-600">{label}</span>
        {rightAction}
      </div>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        autoFocus={autoFocus}
        className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 outline-none transition focus:border-energum-blue focus:ring-2 focus:ring-energum-blue/20"
      />
    </label>
  );
}
