import { useAuth, useRouter } from "../store";

export default function Account() {
  const { user, logout } = useAuth();
  const { navigate } = useRouter();

  if (!user) {
    return (
      <div className="bg-slate-50 py-20 text-center">
        <p className="text-slate-600">Vous n'êtes pas connecté.</p>
        <button onClick={() => navigate({ name: "login" })} className="mt-4 rounded-full bg-energum-blue px-6 py-2.5 text-white">
          Se connecter
        </button>
      </div>
    );
  }

  return (
    <div className="bg-slate-50 py-12">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <div className="overflow-hidden rounded-3xl bg-gradient-to-r from-energum-blue to-blue-700 p-8 text-white shadow-xl">
          <div className="flex flex-col items-start gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-4">
              <span className="grid h-16 w-16 place-items-center rounded-full bg-gradient-to-br from-energum-orange to-energum-amber text-2xl font-extrabold">
                {user.fullName.charAt(0).toUpperCase()}
              </span>
              <div>
                <h1 className="text-2xl font-extrabold">Bonjour, {user.fullName.split(" ")[0]} 👋</h1>
                <p className="text-blue-100/80">Membre depuis le {new Date(user.createdAt).toLocaleDateString("fr-FR")}</p>
              </div>
            </div>
            <button
              onClick={() => {
                logout();
                navigate({ name: "home" });
              }}
              className="rounded-full bg-white/15 px-5 py-2.5 text-sm font-bold backdrop-blur hover:bg-white/25"
            >
              🚪 Se déconnecter
            </button>
          </div>
        </div>

        <div className="mt-8 grid gap-6 md:grid-cols-3">
          <Card title="Mes informations">
            <Row label="Nom" value={user.fullName} />
            <Row label="Email" value={user.email} />
            <Row label="ID client" value={user.id.slice(0, 8).toUpperCase()} />
          </Card>
          <Card title="Mes commandes">
            <p className="text-sm text-slate-600">Vous n'avez pas encore de commande.</p>
            <button onClick={() => navigate({ name: "products" })} className="mt-3 rounded-full bg-energum-orange px-5 py-2 text-sm font-bold text-white">
              Découvrir les produits
            </button>
          </Card>
          <Card title="Mon programme">
            <p className="text-sm text-slate-600">Configurez votre cure mensuelle Focus + Sommeil.</p>
            <button className="mt-3 rounded-full border border-energum-blue px-5 py-2 text-sm font-bold text-energum-blue hover:bg-energum-blue hover:text-white">
              Activer l'abonnement
            </button>
          </Card>
        </div>

        <div className="mt-6 rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
          <h2 className="mb-3 text-lg font-bold text-energum-blue">Avantages membre</h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { i: "🎁", t: "-10% sur 1ère commande" },
              { i: "🚚", t: "Livraison prioritaire" },
              { i: "📚", t: "Guides scientifiques" },
              { i: "💬", t: "Support nutritionniste" },
            ].map((a) => (
              <div key={a.t} className="rounded-2xl bg-slate-50 p-4 text-center">
                <div className="text-3xl">{a.i}</div>
                <div className="mt-1 text-sm font-semibold text-slate-700">{a.t}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
      <h3 className="mb-3 text-base font-bold text-energum-blue">{title}</h3>
      {children}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between border-b border-slate-100 py-2 text-sm last:border-0">
      <span className="text-slate-500">{label}</span>
      <span className="font-semibold text-slate-900">{value}</span>
    </div>
  );
}
