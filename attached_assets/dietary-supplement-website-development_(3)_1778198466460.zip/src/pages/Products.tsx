import ProductBottle from "../components/ProductBottle";
import { products } from "../data/products";
import { useCart, useRouter } from "../store";

export default function Products() {
  const { navigate } = useRouter();
  const { add } = useCart();

    const duoPrice = 529;
    const duoOld = 598;

  return (
    <div className="bg-slate-50">
      <div className="bg-radial-blue py-14 text-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-extrabold sm:text-5xl">Nos produits</h1>
          <p className="mt-3 max-w-2xl text-blue-100/90">
            Une gamme courte, exigeante et complémentaire — chaque formule pensée pour un moment précis de votre journée.
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-2">
          {products.map((p) => {
            const isOrange = p.color === "orange";
            return (
              <article
                key={p.id}
                className="overflow-hidden rounded-3xl bg-white shadow-xl ring-1 ring-slate-200"
              >
                <div
                  className={`relative px-6 py-8 ${
                    isOrange ? "bg-gradient-to-br from-orange-500 to-orange-700" : "bg-gradient-to-br from-energum-blue to-energum-blue-deep"
                  }`}
                >
                  <div className="flex items-end gap-6">
                    <ProductBottle variant={p.color} label={p.slug.toUpperCase()} size={140} />
                    <div className="text-white">
                      <div className="text-xs font-bold uppercase tracking-widest opacity-80">{isOrange ? "JOUR" : "NUIT"}</div>
                      <h2 className="text-2xl font-extrabold">{p.name}</h2>
                      <p className="mt-1 text-sm opacity-90">{p.tagline}</p>
                      <div className="mt-3 flex items-center gap-1 text-sm">
                        <span className="text-energum-amber">{"★".repeat(Math.round(p.rating))}</span>
                        <span className="opacity-80">{p.rating} · {p.reviews} avis</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-sm text-slate-600">{p.description}</p>
                  <ul className="mt-4 grid grid-cols-2 gap-2">
                    {p.benefits.map((b) => (
                      <li key={b.title} className="flex items-start gap-2 rounded-xl bg-slate-50 p-2.5 text-xs">
                        <span className="text-base">{b.icon}</span>
                        <span className="font-semibold text-slate-700">{b.title}</span>
                      </li>
                    ))}
                  </ul>
                      <div className="mt-5 flex items-end justify-between">
                        <div>
                          <div className="text-2xl font-extrabold text-energum-blue">{p.price} MAD</div>
                          {p.oldPrice && <div className="text-sm text-slate-400 line-through">{p.oldPrice} MAD</div>}
                        </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => navigate({ name: "product", slug: p.slug })}
                        className="rounded-full border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50"
                      >
                        Détails
                      </button>
                      <button
                        onClick={() => add(p.id)}
                        className={`rounded-full px-5 py-2 text-sm font-bold text-white shadow-lg ${
                          isOrange ? "bg-energum-orange hover:brightness-110" : "bg-energum-blue hover:brightness-110"
                        }`}
                      >
                        Ajouter
                      </button>
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>

        {/* DUO PACK */}
        <div className="mt-10 overflow-hidden rounded-3xl bg-gradient-to-r from-energum-blue-deep via-energum-blue to-orange-700 p-8 text-white shadow-2xl">
          <div className="grid items-center gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <span className="inline-block rounded-full bg-energum-amber px-3 py-1 text-xs font-extrabold uppercase tracking-widest text-energum-blue-deep">
                ⚡ Offre Duo · -20%
              </span>
              <h3 className="mt-3 text-3xl font-extrabold">Pack ÉQUILIBRE PARFAIT</h3>
              <p className="mt-2 text-blue-100/90">FOCUS + SOMMEIL — la cure complète 1 mois pour optimiser jour et nuit.</p>
              <div className="mt-4 flex items-center gap-3">
                <span className="text-4xl font-extrabold">{duoPrice} MAD</span>
                <span className="text-lg line-through opacity-60">{duoOld} MAD</span>
              </div>
            </div>
            <div className="flex justify-center lg:justify-end">
              <button
                onClick={() => {
                  products.forEach((p) => add(p.id));
                  navigate({ name: "cart" });
                }}
                className="rounded-full bg-energum-amber px-8 py-4 text-base font-extrabold text-energum-blue-deep shadow-xl hover:brightness-110"
              >
                Commander le DUO →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
