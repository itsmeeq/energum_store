import { products } from "../data/products";
import ProductBottle from "../components/ProductBottle";
import { useCart, useRouter } from "../store";

export default function Cart() {
  const { items, update, remove, count } = useCart();
  const { navigate } = useRouter();

  const enriched = items
    .map((i) => ({ item: i, product: products.find((p) => p.id === i.productId)! }))
    .filter((x) => x.product);

  const subtotal = enriched.reduce((s, { item, product }) => s + item.quantity * product.price, 0);
  const shipping = 0;
  const total = subtotal + shipping;

  if (count === 0) {
    return (
      <div className="bg-slate-50 py-20">
        <div className="mx-auto max-w-xl px-4 text-center">
          <div className="text-6xl">🛒</div>
          <h1 className="mt-4 text-3xl font-extrabold text-energum-blue">Votre panier est vide</h1>
          <p className="mt-2 text-slate-600">Découvrez nos formules naturelles pour reprendre le contrôle de votre journée et de vos nuits.</p>
          <button
            onClick={() => navigate({ name: "products" })}
            className="mt-6 rounded-full bg-gradient-to-r from-energum-orange to-energum-amber px-8 py-3.5 text-sm font-bold text-white shadow-xl"
          >
            Voir les produits
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-50 py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-extrabold text-energum-blue sm:text-4xl">Mon panier</h1>
        <p className="mt-1 text-slate-600">{count} article{count > 1 ? "s" : ""}</p>

        <div className="mt-8 grid gap-8 lg:grid-cols-3">
          <div className="space-y-4 lg:col-span-2">
            {enriched.map(({ item, product }) => (
              <div key={product.id} className="flex flex-col gap-4 rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200 sm:flex-row">
                <div className={`flex w-full shrink-0 items-center justify-center rounded-2xl sm:w-32 ${product.color === "orange" ? "bg-orange-100" : "bg-blue-100"}`}>
                  <ProductBottle variant={product.color} label={product.slug.toUpperCase()} size={100} />
                </div>
                <div className="flex flex-1 flex-col justify-between gap-3">
                  <div>
                    <h3 className="text-lg font-bold text-energum-blue">{product.name}</h3>
                    <p className="text-sm text-slate-600">{product.tagline}</p>
                    <div className="mt-1 text-xs text-slate-500">{product.capsules} gummies</div>
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center rounded-full border border-slate-300">
                      <button onClick={() => update(product.id, item.quantity - 1)} className="px-3 py-1.5 font-bold">−</button>
                      <span className="w-8 text-center text-sm font-bold">{item.quantity}</span>
                      <button onClick={() => update(product.id, item.quantity + 1)} className="px-3 py-1.5 font-bold">+</button>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-lg font-extrabold text-energum-blue">{product.price * item.quantity} MAD</span>
                      <button onClick={() => remove(product.id)} className="text-xs font-semibold text-rose-600 hover:underline">
                        Retirer
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <aside className="h-fit rounded-3xl bg-white p-6 shadow-md ring-1 ring-slate-200">
            <h2 className="text-lg font-bold text-energum-blue">Récapitulatif</h2>
            <dl className="mt-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-slate-600">Sous-total</dt>
                <dd className="font-semibold">{subtotal} MAD</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-600">Livraison</dt>
                <dd className="font-semibold"><span className="text-emerald-600">Offerte</span></dd>
              </div>
              <div className="border-t border-slate-200 pt-3">
                <div className="flex items-baseline justify-between">
                  <dt className="text-base font-bold text-energum-blue">Total</dt>
                  <dd className="text-2xl font-extrabold text-energum-blue">{total} MAD</dd>
                </div>
              </div>
            </dl>

            <button
              onClick={() => navigate({ name: "checkout" })}
              className="mt-5 w-full rounded-full bg-gradient-to-r from-energum-orange to-energum-amber py-3 text-sm font-bold text-white shadow-lg hover:brightness-110"
            >
              Passer à la caisse →
            </button>
            <button
              onClick={() => navigate({ name: "products" })}
              className="mt-2 w-full rounded-full border border-slate-300 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50"
            >
              Continuer mes achats
            </button>

            <div className="mt-5 flex flex-col gap-2 text-xs text-slate-500">
              <span>🔒 Paiement sécurisé SSL</span>
              <span>🚚 Livraison en 48h</span>
              <span>🔄 Satisfait ou remboursé 30 jours</span>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
