import type { Product, Review } from "../types";

export const products: Product[] = [
  {
    id: "energum-focus",
    slug: "focus",
    name: "ENERGUM FOCUS",
    tagline: "Énergie pour le jour — Concentration & Performance",
    description:
      "Gummies naturels formulés pour soutenir la concentration, la clarté mentale et la mémoire au quotidien.",
    longDescription:
      "ENERGUM FOCUS est une formule scientifiquement étudiée associant nootropiques d'origine naturelle, vitamines du groupe B et adaptogènes. Idéal pour les étudiants, chercheurs, sportifs et professionnels exigeants, FOCUS aide à maintenir l'attention sur les tâches longues et à réduire la fatigue mentale, sans pic d'énergie ni dépendance.",
    price: 299,
    oldPrice: 399,
    color: "orange",
    capsules: 60,
    rating: 4.8,
    reviews: 1247,
    benefits: [
      { title: "Concentration améliorée", desc: "Soutient l'attention soutenue.", icon: "🎯" },
      { title: "Clarté mentale", desc: "Réduit le brouillard cognitif.", icon: "💡" },
      { title: "Mémoire & apprentissage", desc: "Favorise la plasticité cérébrale.", icon: "🧠" },
      { title: "Anti-fatigue", desc: "Énergie stable toute la journée.", icon: "⚡" },
    ],
    ingredients: [
      { name: "Bacopa Monnieri", dose: "300 mg", role: "Mémoire & apprentissage" },
      { name: "L-Théanine", dose: "200 mg", role: "Focus calme et soutenu" },
      { name: "Ginkgo Biloba", dose: "120 mg", role: "Microcirculation cérébrale" },
      { name: "Rhodiola Rosea", dose: "150 mg", role: "Adaptogène anti-stress" },
      { name: "Vitamine B6 / B9 / B12", dose: "100% AJR", role: "Métabolisme énergétique neuronal" },
      { name: "Caféine naturelle (guarana)", dose: "75 mg", role: "Vigilance" },
    ],
    usage:
      "2 gummies par jour le matin, avec un grand verre d'eau. Cure recommandée : 1 à 3 mois.",
    warnings:
      "Déconseillé aux femmes enceintes/allaitantes et aux enfants de moins de 12 ans. Ne pas dépasser la dose journalière.",
    image: "🟠",
  },
  {
    id: "energum-sommeil",
    slug: "sommeil",
    name: "ENERGUM SOMMEIL",
    tagline: "Récupération pour la nuit — Sommeil réparateur & profond",
    description:
      "Gummies naturels qui favorisent l'endormissement et améliorent la qualité du sommeil profond.",
    longDescription:
      "ENERGUM SOMMEIL associe mélatonine micro-dosée, plantes apaisantes et magnésium bisglycinate pour un endormissement rapide, un sommeil ininterrompu et un réveil sans fatigue. Sans accoutumance, sans réveil brumeux.",
    price: 299,
    oldPrice: 399,
    color: "blue",
    capsules: 60,
    rating: 4.9,
    reviews: 982,
    benefits: [
      { title: "Endormissement rapide", desc: "En moyenne 18 minutes.", icon: "🌙" },
      { title: "Sommeil profond", desc: "Augmente le sommeil réparateur.", icon: "💤" },
      { title: "Réveil sans fatigue", desc: "Récupération mentale optimale.", icon: "☀️" },
      { title: "Anti-stress du soir", desc: "Apaise le système nerveux.", icon: "🧘" },
    ],
    ingredients: [
      { name: "Mélatonine", dose: "1.9 mg", role: "Régule le cycle circadien" },
      { name: "Magnésium bisglycinate", dose: "300 mg", role: "Détente musculaire & nerveuse" },
      { name: "Valériane", dose: "250 mg", role: "Sommeil profond" },
      { name: "Passiflore", dose: "200 mg", role: "Apaisement mental" },
      { name: "Camomille", dose: "150 mg", role: "Relaxation" },
      { name: "Vitamine B6", dose: "100% AJR", role: "Synthèse de la sérotonine" },
    ],
    usage:
      "2 gummies 30 minutes avant le coucher. Convient à un usage régulier ou ponctuel.",
    warnings:
      "Déconseillé avant la conduite. Femmes enceintes/allaitantes : avis médical requis.",
    image: "🔵",
  },
];

export const reviews: Review[] = [
  {
    id: "r1",
    productId: "energum-focus",
    author: "Yasmine B.",
    rating: 5,
    title: "Parfait pour la rédaction du mémoire",
    body: "Je termine mon master et FOCUS m'a vraiment aidée pour les longues sessions de lecture. Pas de coup de barre.",
    date: "2026-01-12",
  },
  {
    id: "r2",
    productId: "energum-focus",
    author: "Karim L.",
    rating: 5,
    title: "Concentration de fond",
    body: "Effet progressif mais réel après 2 semaines. Je l'associe à un café le matin.",
    date: "2026-02-04",
  },
  {
    id: "r3",
    productId: "energum-focus",
    author: "Sofia M.",
    rating: 4,
    title: "Bien, goût agréable",
    body: "Texture des gummies super, effet notable sur la mémoire à court terme.",
    date: "2026-02-22",
  },
  {
    id: "r4",
    productId: "energum-sommeil",
    author: "Hicham A.",
    rating: 5,
    title: "Adieu insomnie",
    body: "Je m'endors en 15 minutes au lieu d'une heure. Réveil clair, pas groggy.",
    date: "2026-01-30",
  },
  {
    id: "r5",
    productId: "energum-sommeil",
    author: "Léa P.",
    rating: 5,
    title: "Récupération nette",
    body: "Sommeil plus profond, ma montre confirme +25% de sommeil profond.",
    date: "2026-02-18",
  },
  {
    id: "r6",
    productId: "energum-sommeil",
    author: "Omar T.",
    rating: 4,
    title: "Très bon en complément",
    body: "Je l'utilise les soirs de stress, parfait sans accoutumance.",
    date: "2026-03-02",
  },
];
