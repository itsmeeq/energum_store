import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { CartItem, Route, User } from "./types";

// ---------- Router ----------
type RouterCtx = {
  route: Route;
  navigate: (r: Route) => void;
};
const RouterContext = createContext<RouterCtx | null>(null);

function parseHash(): Route {
  const h = window.location.hash.replace(/^#\/?/, "");
  if (!h) return { name: "home" };
  const [base, param] = h.split("/");
  switch (base) {
    case "products":
      return { name: "products" };
    case "product":
      if (param === "focus" || param === "sommeil") return { name: "product", slug: param };
      return { name: "products" };
    case "science":
      return { name: "science" };
    case "about":
      return { name: "about" };
    case "contact":
      return { name: "contact" };
    case "cart":
      return { name: "cart" };
    case "checkout":
      return { name: "checkout" };
    case "login":
      return { name: "login" };
    case "register":
      return { name: "register" };
    case "account":
      return { name: "account" };
    default:
      return { name: "home" };
  }
}

function routeToHash(r: Route): string {
  switch (r.name) {
    case "home":
      return "#/";
    case "product":
      return `#/product/${r.slug}`;
    default:
      return `#/${r.name}`;
  }
}

export function RouterProvider({ children }: { children: ReactNode }) {
  const [route, setRoute] = useState<Route>(() => parseHash());
  useEffect(() => {
    const onHash = () => {
      setRoute(parseHash());
      window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);
  const navigate = useCallback((r: Route) => {
    window.location.hash = routeToHash(r);
  }, []);
  return <RouterContext.Provider value={{ route, navigate }}>{children}</RouterContext.Provider>;
}

export function useRouter() {
  const ctx = useContext(RouterContext);
  if (!ctx) throw new Error("RouterProvider missing");
  return ctx;
}

// ---------- Auth ----------
type AuthCtx = {
  user: User | null;
  login: (email: string, password: string) => { ok: boolean; error?: string };
  register: (fullName: string, email: string, password: string) => { ok: boolean; error?: string };
  logout: () => void;
};
const AuthContext = createContext<AuthCtx | null>(null);

const USERS_KEY = "energum_users";
const SESSION_KEY = "energum_session";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const s = localStorage.getItem(SESSION_KEY);
      return s ? (JSON.parse(s) as User) : null;
    } catch {
      return null;
    }
  });

  const persistSession = (u: User | null) => {
    if (u) localStorage.setItem(SESSION_KEY, JSON.stringify(u));
    else localStorage.removeItem(SESSION_KEY);
    setUser(u);
  };

  const readUsers = (): User[] => {
    try {
      return JSON.parse(localStorage.getItem(USERS_KEY) || "[]");
    } catch {
      return [];
    }
  };
  const writeUsers = (list: User[]) => localStorage.setItem(USERS_KEY, JSON.stringify(list));

  const register: AuthCtx["register"] = (fullName, email, password) => {
    if (!fullName.trim() || !email.trim() || !password) return { ok: false, error: "Tous les champs sont requis." };
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return { ok: false, error: "Email invalide." };
    if (password.length < 6) return { ok: false, error: "Mot de passe : 6 caractères minimum." };
    const users = readUsers();
    if (users.find((u) => u.email.toLowerCase() === email.toLowerCase()))
      return { ok: false, error: "Cet email est déjà utilisé." };
    const newUser: User = {
      id: crypto.randomUUID(),
      fullName: fullName.trim(),
      email: email.trim().toLowerCase(),
      password,
      createdAt: new Date().toISOString(),
    };
    writeUsers([...users, newUser]);
    persistSession(newUser);
    return { ok: true };
  };

  const login: AuthCtx["login"] = (email, password) => {
    const users = readUsers();
    const found = users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
    if (!found) return { ok: false, error: "Aucun compte avec cet email." };
    if (found.password !== password) return { ok: false, error: "Mot de passe incorrect." };
    persistSession(found);
    return { ok: true };
  };

  const logout = () => persistSession(null);

  const value = useMemo(() => ({ user, login, register, logout }), [user]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("AuthProvider missing");
  return ctx;
}

// ---------- Cart ----------
type CartCtx = {
  items: CartItem[];
  add: (productId: string, qty?: number) => void;
  remove: (productId: string) => void;
  update: (productId: string, qty: number) => void;
  clear: () => void;
  count: number;
};
const CartContext = createContext<CartCtx | null>(null);
const CART_KEY = "energum_cart";

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      return JSON.parse(localStorage.getItem(CART_KEY) || "[]");
    } catch {
      return [];
    }
  });
  useEffect(() => {
    localStorage.setItem(CART_KEY, JSON.stringify(items));
  }, [items]);

  const add: CartCtx["add"] = (productId, qty = 1) => {
    setItems((prev) => {
      const existing = prev.find((i) => i.productId === productId);
      if (existing)
        return prev.map((i) => (i.productId === productId ? { ...i, quantity: i.quantity + qty } : i));
      return [...prev, { productId, quantity: qty }];
    });
  };
  const remove: CartCtx["remove"] = (productId) =>
    setItems((prev) => prev.filter((i) => i.productId !== productId));
  const update: CartCtx["update"] = (productId, qty) => {
    if (qty <= 0) return remove(productId);
    setItems((prev) => prev.map((i) => (i.productId === productId ? { ...i, quantity: qty } : i)));
  };
  const clear = () => setItems([]);
  const count = items.reduce((s, i) => s + i.quantity, 0);

  const value = useMemo(() => ({ items, add, remove, update, clear, count }), [items, count]);
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("CartProvider missing");
  return ctx;
}
