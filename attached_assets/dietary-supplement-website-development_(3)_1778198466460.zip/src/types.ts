export type Product = {
  id: string;
  slug: "focus" | "sommeil";
  name: string;
  tagline: string;
  description: string;
  longDescription: string;
  price: number;
  oldPrice?: number;
  color: "orange" | "blue";
  capsules: number;
  rating: number;
  reviews: number;
  benefits: { title: string; desc: string; icon: string }[];
  ingredients: { name: string; dose: string; role: string }[];
  usage: string;
  warnings: string;
  image: string;
};

export type User = {
  id: string;
  fullName: string;
  email: string;
  password: string; // demo only — stored locally
  createdAt: string;
};

export type CartItem = {
  productId: string;
  quantity: number;
};

export type Review = {
  id: string;
  productId: string;
  author: string;
  rating: number;
  title: string;
  body: string;
  date: string;
};

export type Route =
  | { name: "home" }
  | { name: "products" }
  | { name: "product"; slug: "focus" | "sommeil" }
  | { name: "science" }
  | { name: "about" }
  | { name: "contact" }
  | { name: "cart" }
  | { name: "checkout" }
  | { name: "login" }
  | { name: "register" }
  | { name: "account" };
