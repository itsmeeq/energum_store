import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import Products from "./pages/Products";
import ProductDetail from "./pages/ProductDetail";
import Cart from "./pages/Cart";
import Checkout from "./pages/Checkout";
import Account from "./pages/Account";
import { Login, Register } from "./pages/Auth";
import { About, Contact, Science } from "./pages/Static";
import { AuthProvider, CartProvider, RouterProvider, useRouter } from "./store";

function Pages() {
  const { route } = useRouter();
  switch (route.name) {
    case "home":
      return <Home />;
    case "products":
      return <Products />;
    case "product":
      return <ProductDetail slug={route.slug} />;
    case "science":
      return <Science />;
    case "about":
      return <About />;
    case "contact":
      return <Contact />;
    case "cart":
      return <Cart />;
    case "checkout":
      return <Checkout />;
    case "account":
      return <Account />;
    case "login":
      return <Login />;
    case "register":
      return <Register />;
    default:
      return <Home />;
  }
}

function Shell() {
  const { route } = useRouter();
  const hideChrome = route.name === "login" || route.name === "register";
  return (
    <div className="flex min-h-screen flex-col bg-white">
      {!hideChrome && <Navbar />}
      {hideChrome && (
        <div className="absolute left-0 right-0 top-0 z-10">
          {/* keep nothing, login page has its own layout */}
        </div>
      )}
      <main className="flex-1">
        <Pages />
      </main>
      {!hideChrome && <Footer />}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <RouterProvider>
          <Shell />
        </RouterProvider>
      </CartProvider>
    </AuthProvider>
  );
}
